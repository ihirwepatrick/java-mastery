package com.thread.threadApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
