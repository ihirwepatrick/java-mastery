 ## thread application
 
java application for exporting database contents using threads