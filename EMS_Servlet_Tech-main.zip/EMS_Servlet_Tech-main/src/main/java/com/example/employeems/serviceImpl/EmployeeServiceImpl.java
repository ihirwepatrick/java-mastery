package com.example.employeems.services;

import com.example.employeems.models.Employee;

import java.util.List;

public class EmployeeServiceImpl implements EmployeeService{
    @Override
    public void addEmployee(Employee employee) {
        
    }

    @Override
    public List<Employee> getAllEmployees() {
        return List.of();
    }

    @Override
    public Employee getEmployeeById(int id) {
        return null;
    }

    @Override
    public void updateEmployee(Employee employee) {

    }

    @Override
    public void deleteEmployee(int id) {

    }
}
