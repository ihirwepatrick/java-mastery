package com.example.employeems.DAO;

public interface EmployeeDAO {
}
