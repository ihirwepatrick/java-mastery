package com.example.employeems.services;

public interface UserService {
}
